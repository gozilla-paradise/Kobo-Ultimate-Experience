return {
    _A_ = {
        "A",
        north = "Â",
        south = "Ă",
    },
    _a_ = {
        "a",
        north = "â",
        south = "ă",
    },
    _I_ = {
        "I",
        north = "Î",
        south = "Ĭ",
    },
    _i_ = {
        "i",
        north = "î",
        south = "ĭ",
    },
    _S_ = {
        "S",
        north = "Ș",
    },
    _s_ = {
        "s",
        north = "ș",
    },
    _T_ = {
        "T",
        north = "Ț",
    },
    _t_ = {
        "t",
        north = "ț",
    },
    _U_ = {
        "U",
        south = "Ŭ",
    },
    _u_ = {
        "u",
        south = "ŭ",
    },
}
